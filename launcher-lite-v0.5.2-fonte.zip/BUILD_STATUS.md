# Launcher Lite 0.5.2 — status de validação

Base: ZIP da branch main, commit dfae41f4aa6f7ef6e2cf968ada8efb4267c6b0e1 (0.5.1 / versionCode 12).

- Versão atualizada: 0.5.2 / versionCode 13.
- 15 verificações da política de recuperação executadas no JVM: aprovadas.
- XMLs de recursos e manifesto analisados: válidos.
- Compilação Android e assinatura de release: pendentes (SDK/Gradle não disponíveis no ambiente local).
- Teste físico de HOME, painel lateral, reinicialização e standby no Realme Stick Android 14: pendente.
- Workflow e configuração da assinatura permanente mantidos. Não foram incluídas chaves, senhas ou tokens.

## Mudanças

O serviço opcional trata somente HOME se a função HOME pertencer ao Lite e a tela estiver interativa. A recuperação secundária é programada apenas para atividades HOME conhecidas, com cancelamento ao observar outra janela ou outro comando do controle. A entrega da tecla HOME ao serviço depende do sistema. O serviço não lê conteúdo das janelas e não altera o Google TV original.

A atividade deixa de forçar o modo imersivo e cancela o protetor de tela e o agendamento do assistente quando perde foco. O assistente valida HOME, acessibilidade e notificações em etapas; as autorizações opcionais podem ser puladas. O Android continua responsável por conceder acessos especiais.

## Compilação oficial

Atualizar os arquivos na branch main do repositório original, preservando os quatro GitHub Secrets de assinatura. O workflow Build Android APK valida assembleDebug e executa assembleRelease com a chave permanente. Após sucesso, baixar o artefato minimal-tv-launcher-apk e extrair app-release.apk. Não instalar APK debug sobre o aplicativo assinado.

## Teste na TV

1. Atualizar sem desinstalar, mantendo o Google TV original instalado e habilitado.
2. Concluir o assistente e selecionar Launcher Lite como HOME. Se quiser usar a compatibilidade de HOME, habilitar seu serviço opcional. Durante o teste, não usar simultaneamente outro serviço de remapeamento de HOME.
3. Abrir outro app e apertar HOME repetidamente; abrir o painel lateral pela engrenagem e verificar se permanece até ser fechado pelo usuário.
4. Testar saída do standby e reinicialização completa separadamente.
5. Se falhar, consultar apenas os registros da nova implementação com: logcat -d -s LauncherLiteHome

Teste unitário local (Kotlin CLI):

```
kotlinc app/src/main/java/br/com/launcher/tv/HomeRecoveryPolicy.kt tests/HomeRecoveryPolicyTest.kt -include-runtime -d /tmp/launcher-policy-test.jar
java -jar /tmp/launcher-policy-test.jar
```
