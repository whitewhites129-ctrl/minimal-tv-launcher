package br.com.launcher.tv

fun main() {
    val google = "com.google.android.apps.tv.launcherx"
    val legacy = "com.google.android.tvlauncher"
    check(HomeRecoveryPolicy.isStockHome(google, "$google.home.HomeActivity"))
    check(HomeRecoveryPolicy.isStockHome(google, ".home.HomeActivity"))
    check(HomeRecoveryPolicy.isStockHome(legacy, "$legacy.MainActivity"))
    check(!HomeRecoveryPolicy.isStockHome(google, "android.app.Dialog"))
    check(!HomeRecoveryPolicy.isStockHome(google, "$google.settings.SettingsActivity"))
    check(!HomeRecoveryPolicy.isStockHome("com.android.tv.settings", "com.android.tv.settings.MainActivity"))
    check(!HomeRecoveryPolicy.isStockHome("com.klevico.monet", "com.klevico.monet.HomeActivity"))
    check(!HomeRecoveryPolicy.isStockHome("br.com.launcher.tv", "br.com.launcher.tv.MainActivity"))
    check(!HomeRecoveryPolicy.isStockHome(google, null))
    check(!HomeRecoveryPolicy.canLaunch(false, true, 1000L, null))
    check(!HomeRecoveryPolicy.canLaunch(true, false, 1000L, null))
    check(HomeRecoveryPolicy.canLaunch(true, true, 1000L, null))
    check(!HomeRecoveryPolicy.canLaunch(true, true, 1649L, 1000L))
    check(HomeRecoveryPolicy.canLaunch(true, true, 1650L, 1000L))
    check(HomeRecoveryPolicy.RECOVERY_DELAY_MS > HomeRecoveryPolicy.MIN_LAUNCH_INTERVAL_MS)
    println("15 checks passed (JVM policy only)")
}
