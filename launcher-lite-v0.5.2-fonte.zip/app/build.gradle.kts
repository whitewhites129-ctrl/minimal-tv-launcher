plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "br.com.launcher.tv"
    compileSdk = 35

    defaultConfig {
        applicationId = "br.com.launcher.tv"
        minSdk = 23
        targetSdk = 28
        versionCode = 13
        versionName = "0.5.2"
    }

    // Keep targetSdk 28 for the launcher compatibility behavior being tested.
    // Suppress only the release lint check that rejects this legacy target.
    lint {
        disable += "ExpiredTargetSdkVersion"
    }

    val releaseStoreFile = System.getenv("ANDROID_KEYSTORE_PATH")
    val releaseStorePassword = System.getenv("ANDROID_KEYSTORE_PASSWORD")
    val releaseKeyAlias = System.getenv("ANDROID_KEY_ALIAS")
    val releaseKeyPassword = System.getenv("ANDROID_KEY_PASSWORD")

    signingConfigs {
        if (!releaseStoreFile.isNullOrBlank()) {
            create("persistentRelease") {
                storeFile = file(releaseStoreFile)
                storePassword = releaseStorePassword
                keyAlias = releaseKeyAlias
                keyPassword = releaseKeyPassword
            }
        }
    }

    buildTypes {
        release {
            if (!releaseStoreFile.isNullOrBlank()) {
                signingConfig = signingConfigs.getByName("persistentRelease")
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
