package br.com.launcher.tv

import android.accessibilityservice.AccessibilityService
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.util.Log
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

/** User-authorized, narrowly scoped HOME compatibility. No window content access. */
class LauncherAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var lastLaunch: Long? = null
    private var capturedHome = false
    private var stockHomeVisible = false
    private val recover = Runnable {
        if (stockHomeVisible) launchHome("stock-home-fallback")
    }

    private fun isLauncherLiteDefaultHome(): Boolean = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            getSystemService(RoleManager::class.java)?.isRoleHeld(RoleManager.ROLE_HOME) == true
        } else {
            packageManager.resolveActivity(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME),
                PackageManager.MATCH_DEFAULT_ONLY
            )?.activityInfo?.packageName == packageName
        }
    } catch (_: Exception) { false }

    private fun launchHome(reason: String): Boolean {
        val now = SystemClock.elapsedRealtime()
        val interactive = getSystemService(PowerManager::class.java)?.isInteractive == true
        if (!HomeRecoveryPolicy.canLaunch(isLauncherLiteDefaultHome(), interactive, now, if (reason == "home-key") null else lastLaunch)) return false
        return try {
            val launch = Intent(this, MainActivity::class.java).apply {
                action = Intent.ACTION_MAIN
                addCategory(Intent.CATEGORY_HOME)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            }
            startActivity(launch)
            lastLaunch = now
            Log.i("LauncherLiteHome", "HOME launch requested: $reason")
            true
        } catch (e: Exception) {
            Log.w("LauncherLiteHome", "HOME launch rejected: $reason", e)
            false
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.i("LauncherLiteHome", "Accessibility service connected")
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        // Never consume Settings, Back, Power, volume or other remote buttons.
        if (event.keyCode != KeyEvent.KEYCODE_HOME) {
            // A hardware interaction other than HOME cancels a pending recovery.
            if (event.action == KeyEvent.ACTION_DOWN) cancelRecovery()
            return false
        }
        if (event.action == KeyEvent.ACTION_DOWN) {
            if (event.repeatCount != 0) return capturedHome
            cancelRecovery()
            capturedHome = launchHome("home-key")
            return capturedHome
        }
        if (event.action == KeyEvent.ACTION_UP) {
            val consumed = capturedHome
            capturedHome = false
            return consumed
        }
        return false
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        // A later panel, dialog, or app event cancels the pending launch. Never
        // recover solely because a window belongs to the original launcher.
        val exactHome = HomeRecoveryPolicy.isStockHome(event.packageName?.toString(), event.className?.toString())
        cancelRecovery()
        if (!exactHome || !isLauncherLiteDefaultHome()) return
        stockHomeVisible = true
        handler.postDelayed(recover, HomeRecoveryPolicy.RECOVERY_DELAY_MS)
        Log.d("LauncherLiteHome", "Stock HOME activity observed; recovery pending")
    }

    private fun cancelRecovery() {
        stockHomeVisible = false
        handler.removeCallbacks(recover)
    }

    override fun onInterrupt() {
        cancelRecovery()
        capturedHome = false
    }

    override fun onDestroy() {
        cancelRecovery()
        super.onDestroy()
    }
}
