package br.com.launcher.tv

/** Exact activities, not every window belonging to the Google TV package. */
internal object HomeRecoveryPolicy {
    const val RECOVERY_DELAY_MS = 850L
    const val MIN_LAUNCH_INTERVAL_MS = 650L

    fun isStockHome(pkg: String?, className: String?): Boolean {
        if (pkg == null || className == null) return false
        val fullName = if (className.startsWith('.')) pkg + className else className
        return when (pkg) {
            "com.google.android.apps.tv.launcherx" -> fullName == "$pkg.home.HomeActivity"
            "com.google.android.tvlauncher" -> fullName == "$pkg.MainActivity"
            else -> false
        }
    }

    fun canLaunch(roleHeld: Boolean, interactive: Boolean, now: Long, previous: Long?): Boolean =
        roleHeld && interactive && (previous == null || now - previous >= MIN_LAUNCH_INTERVAL_MS)
}
